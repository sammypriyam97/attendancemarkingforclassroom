package com.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.AbsentForm;
import com.bean.FeedbackClass;
import com.bean.LoginClass;
import com.bean.Registration;
import com.dao.DBdao;

public class DBservice {

	DBdao dao=new DBdao();
	public int setUserData(Registration r) throws SQLException
	{
	int x=0;
	 x=dao.setUserData(r);
	 return x;
	}
	
	
	
	public int setValidateLogin( LoginClass lc) throws SQLException{
		int x;
		x=dao.setValidateLogin(lc);
		return x;
	}
	public ArrayList<LoginClass> PAList() throws Exception
	{
		ArrayList<LoginClass> al=dao.PAList();
		
		return al;
	}
	public boolean sendfeedback() {
		int b=dao.sendfeedback();
		if(b==0)
			return false;
		else 
			return true;
	}
	
	public int setFeedbackData (FeedbackClass fc) throws SQLException
	{
	int x=0;
	 x=dao.setFeedbackData(fc);
	 return x;
	}


	public boolean sendNotification() {
		int b=dao.sendNotification();
		if(b==0)
			return false;
		else 
			return true;
	}
	public boolean attandance(int id) {
		int b=dao.getattandance(id);
		if(b==0)
			return false;
		else 
			return true;
		// TODO Auto-generated method stub
		
	}
	
	public int setLoginUserData(LoginClass lc) throws SQLException
	{
		int x=0;
		x=dao.setLoginUserData(lc);
		return x;
	}
	public boolean setWebEx( LoginClass lc) throws SQLException{
		boolean b=dao.setWebEx(lc);
		if(b){
			return true;
		}
		else{
		return false;
		}
	}
	public boolean setWebEx1( LoginClass lc) throws SQLException{
		boolean b=dao.setWebEx1(lc);
		if(b){
			return true;
		}
		else{
		return false;
		}
	}
	public boolean changePassword( LoginClass lc) throws SQLException{
		boolean b=dao.changePassword(lc);
		if(b){
			return true;
		}
		else{
		return false;
		}
	}
	public boolean notification(int id) throws SQLException {
		boolean b=dao.getnotification(id);
		if(b){
			return true;
		}
		else {
			return false;
		}
		// TODO Auto-generated method stub
		
	}
	public int setAbsentReason(AbsentForm af) throws SQLException
	{
	int x=0;
	 x=dao.setAbsentReason(af);
	 return x;
	}
	public String getName(int id) throws SQLException
	{
	
	String x=dao.getname(id);
	 return x;
	}
	public ArrayList<AbsentForm> PAList1() throws Exception
	{
		ArrayList<AbsentForm> arr=dao.PAList1();
		
		return arr;
	}
	public ArrayList<FeedbackClass> PAList2() throws Exception
	{
		ArrayList<FeedbackClass> arr=dao.PAList2();
		
		return arr;
	}
	public int autoIncrement () throws SQLException
	{
	int x=dao.autoIncrement();
	 return x;
	}
	public int  DeleteFeedback () throws SQLException
	{
	int x=dao.DeleteFeedback();
	 return x;
	}
	public int  DeleteAbsentform() throws SQLException
	{
	int y=dao.DeleteAbsentform();
	 return y;
	}
	public int  changeLogin() throws SQLException
	{
	int y=dao.changeLogin();
	 return y;
	}
		// TODO Auto-generated method stub
		
	
}
