create sequence loginSeq
start with 2
minvalue 0
increment by 1;


create trigger loginTrig
before insert on login
for each row
begin
	select loginSeq.nextval
	into :new.empid
	from dual;
end;