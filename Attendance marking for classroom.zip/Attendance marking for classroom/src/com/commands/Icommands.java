package com.commands;

public interface  Icommands {
	
	
		String q1="insert into registration values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		String q2="select * from login where empid=? and pwd=?";
		String q3="select * from login order by empid";
		String q4="UPDATE login SET feedbackstatus = ? WHERE attendance=?";
		String q5="insert into Feedback values(?,?,?,?,?)";
		String q6="UPDATE login SET message = ? WHERE attendance=?";
		String q7="UPDATE login SET attendance = ? WHERE empid=?";
		String q8="insert into login (empid, pwd, type, attendance) values(?,?,?,?)";
		String q9="select * from login where empid=? ";
		String q10="update login SET pwd=? where empid=? and pwd=? ";
		String q11="select * from login where empid=? ";
		String q12="insert into AbsentForm values(?,?,?)";
		String q13="select fname from registration where empid=?";
		String q14="select * from AbsentForm order by empid ";
		String q15="select * from feedback order by empid";
		String q16="select max(empid+1) from login";
		String q17="Delete from feedback";
		String q18="Delete from Absentform";
		String q19 = "update login set attendance='Absent' , feedbackstatus=null , message= null where empid!=1";
		
}
