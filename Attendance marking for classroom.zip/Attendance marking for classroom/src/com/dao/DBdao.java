package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.AbsentForm;
import com.bean.FeedbackClass;
import com.bean.LoginClass;
import com.bean.Registration;
import com.commands.Icommands;
import com.util.DbUtil;

public class DBdao implements Icommands{
	
	
	public int setUserData(Registration r) throws SQLException
	{
		try{
		int x=0;
		Connection con=DbUtil.getConnection();
		String str=q1;
		PreparedStatement psmt=con.prepareStatement(str);
		psmt.setString(1,r.getFname());
		psmt.setString(2,r.getLname());
		psmt.setInt(3,r.getAge());
		psmt.setString(4,r.getGender());
		psmt.setDouble(5,r.getCno());
		psmt.setString(6,r.getEmail());
		psmt.setString(7,r.getPwd());
		psmt.setInt(8,r.getWeight());
		psmt.setString(9,r.getState());
		psmt.setString(10,r.getArea());
		psmt.setInt(11,r.getPin());
		psmt.setString(12,r.getBgp());
		psmt.setInt(13,r.getEmpid());
		x=psmt.executeUpdate();
		con.close();
		return x;
		
		}
	
		catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	

	public static int setValidateLogin(LoginClass lc) throws SQLException
	{
		
		try{
			Connection con=DbUtil.getConnection();
			String str=q2;
			PreparedStatement ps=con.prepareStatement(str);
			
			ps.setInt(1, lc.getEmpid());
			ps.setString(2,lc.getPwd());
			
			ResultSet rs=ps.executeQuery();
			
			int x=0;
			if(rs.next())
			{
				String utype=rs.getString(3);
				  if(utype.equals("user"))
				  {  x=1;
					  return x;
				  }
				  else if(utype.equals("admin"))
				  {  x=2;
					  return x;
			}			
				 
			
			}
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return 3;
	}

	public ArrayList<LoginClass> PAList() throws Exception
	{ 
		try{
			ArrayList<LoginClass> al=new ArrayList<LoginClass>();
		Connection con=DbUtil.getConnection();
		String str=q3;
		PreparedStatement psmt=con.prepareStatement(str);
		ResultSet rs=psmt.executeQuery();
		while(rs.next())
		{
			int empid=rs.getInt(1);
			String pass=rs.getString(2);
			String type=rs.getString(3);
			String attend=rs.getString(4);
			
			al.add(new LoginClass(empid, pass, attend, type));
		}
		con.close();
		return al;
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
		
	}

	public int sendfeedback() {
		try {
					
					Connection con=null;
					con = DbUtil.getConnection(); 
					
					String str=q4;
					PreparedStatement ps=con.prepareStatement(str);
					ps.setString(1,"yes");
					ps.setString(2,"present");
					int b=ps.executeUpdate();
					con.close();
					return b;
				
				}
				catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return 0;
			}
	
	public int setFeedbackData(FeedbackClass fc) throws SQLException
	{
		try{
		int x=0;
		Connection con=DbUtil.getConnection();
		String str=q5;
		PreparedStatement psmt=con.prepareStatement(str);
		psmt.setInt(1,fc.getEmpid());
		psmt.setString(2, fc.getTraining());
		psmt.setString(3, fc.getSatisfaction());
		psmt.setString(4, fc.getAttended_before());
		psmt.setString(5, fc.getRecommend());
		
		x=psmt.executeUpdate();
		con.close();
		return x;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	public int sendNotification() {
		try {
			
			Connection con=null;
			con = DbUtil.getConnection(); 
			String str=q6;
			PreparedStatement ps=con.prepareStatement(str);
			ps.setString(1,"you have been marked Absent");
			ps.setString(2, "Absent");
			int b=ps.executeUpdate();
			con.close();
			return b;
		
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	
	public int getattandance(int id) {
		try {
			
			Connection con=null;
			con = DbUtil.getConnection(); 
			
			String str=q7;
			PreparedStatement ps=con.prepareStatement(str);
			ps.setString(1,"present");
			ps.setInt(2,id);
			int b=ps.executeUpdate();
			con.close();
			return b;
	
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	
	
	public int setLoginUserData(LoginClass lc) throws SQLException
	{
		int x=0;
		try {
		Connection con=null;
		con = DbUtil.getConnection();
		String str=q8;
		PreparedStatement ps=con.prepareStatement(str);
		ps.setInt(1, lc.getEmpid());
		ps.setString(2,lc.getPwd());
		ps.setString(3,"user");
		ps.setString(4,"Absent");
		x=ps.executeUpdate();
		con.close();
		return x;
	}
		catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
		
	public static boolean setWebEx(LoginClass lc) throws SQLException
	{
		
		try{
			
			Connection con=DbUtil.getConnection();
			String str=q9;
			PreparedStatement ps=con.prepareStatement(str);
			
			ps.setInt(1, lc.getEmpid());
			
			
			ResultSet rs=ps.executeQuery();
			
			String feedbackstatus="no value";
			if(rs.next())
			{
				feedbackstatus=rs.getString(5);
				
				  if(feedbackstatus.equals("yes"))
				  { 
					 return true;
				  }
				 
			}
			else
			{
				System.out.println(feedbackstatus);

			}
			con.close();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
		
	}

	
	public static boolean setWebEx1(LoginClass lc) throws SQLException
	{
		
		try{
			
			Connection con=DbUtil.getConnection();
			String str=q9;
			PreparedStatement ps=con.prepareStatement(str);
			
			ps.setInt(1, lc.getEmpid());
			
			
			ResultSet rs=ps.executeQuery();
			
			String feedbackstatus="no value";
			if(rs.next())
			{
				feedbackstatus=rs.getString(6);
				
				  if(feedbackstatus.equals("you have been marked Absent"))
				  { 
					 return true;
				  }
				 
			}
			else
			{
				System.out.println(feedbackstatus);

			}
			con.close();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
		
	}

	public static boolean changePassword(LoginClass lc) throws SQLException
	{
		
		try{
			
			Connection con=DbUtil.getConnection();
			String str=q10;
			PreparedStatement ps=con.prepareStatement(str);
			ps.setString(1,lc.getNewPassword());
			ps.setInt(2,lc.getEmpid());
			ps.setString(3,lc.getPwd());
			
			ResultSet rs=ps.executeQuery();
		
			if(rs.next())
			{
				con.close();
					 return true;
				  }
				
			else
			{
				con.close();
				return false;

			}

		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return false;
		
	}
	
	public static boolean getnotification (int id) throws SQLException
	{
		
		try{
			
			
			Connection con=DbUtil.getConnection();
			String str=q11;
			PreparedStatement ps=con.prepareStatement(str);
			ps.setInt(1, id);
			
			ResultSet rs=ps.executeQuery();
			
			String attendance="no value";
			if(rs.next())
			{
			attendance =rs.getString(4);
		
			if(attendance.equalsIgnoreCase("Present")){
				
				con.close();
				return true;
				
			}
			else{
				
		
			con.close();
				return false;
			}
			}
		}
		catch(Exception e){
			e.printStackTrace();
			
		}
		return false;
		
	}
	public int setAbsentReason(AbsentForm af) throws SQLException
	{
		try{
		int x=0;
		Connection con=DbUtil.getConnection();
		String str=q12;
		PreparedStatement psmt=con.prepareStatement(str);
		psmt.setInt(1,af.getEmpid());
		psmt.setString(2,af.getCourse());
		psmt.setString(3,af.getReason());
		x=psmt.executeUpdate();
		con.close();
		return x;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	public String getname(int id) throws SQLException
	{
		try{
		
		Connection con=DbUtil.getConnection();
		String str=q13;
		PreparedStatement psmt=con.prepareStatement(str);
		psmt.setInt(1,id);
		
		ResultSet rs=psmt.executeQuery();
		rs.next();
		String x= rs.getString(1);	
		con.close();
		return x;
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public ArrayList<AbsentForm> PAList1() throws Exception
	{ 
		try{
			ArrayList<AbsentForm> arr=new ArrayList<AbsentForm>();
		Connection con=DbUtil.getConnection();
		String str=q14;
		PreparedStatement psmt=con.prepareStatement(str);
		ResultSet rs=psmt.executeQuery();
		while(rs.next())
		{
			int empid=rs.getInt(1);
			String course=rs.getString(2);
			String reason=rs.getString(3);
			
			
			arr.add(new AbsentForm(empid,course,reason));
		}
		con.close();
		return arr;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
		
	}
	
	public ArrayList<FeedbackClass> PAList2() throws Exception
	{ 
		try{
			ArrayList<FeedbackClass> arr=new ArrayList<FeedbackClass>();
		Connection con=DbUtil.getConnection();
		String str=q15;
		PreparedStatement psmt=con.prepareStatement(str);
		ResultSet rs=psmt.executeQuery();
		while(rs.next())
		{
			int empid=rs.getInt(1);
			String training=rs.getString(2);
			String satisfaction=rs.getString(3);
			String attended=rs.getString(4);
			String recommend=rs.getString(5);
			//LoginClass lc=new LoginClass(empid, pass, attend, type);
		
			arr.add(new FeedbackClass(empid,training,satisfaction,attended,recommend));
		}
		con.close();
		return arr;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	public int autoIncrement() {
		try {
			int empid = 0;
			Connection con=null;
			con = DbUtil.getConnection(); 
			String str=q16;
			PreparedStatement psmt=con.prepareStatement(str);
			ResultSet rs=psmt.executeQuery();
			if(rs.next()){
				empid=rs.getInt(1);
			}
			
			con.close();
			return empid;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	public static int DeleteFeedback() throws SQLException
	{
		try{
			Connection con=DbUtil.getConnection();
			String str1=q17;
			PreparedStatement ps1=con.prepareStatement(str1);
			int a =ps1.executeUpdate();
			
			con.close();
			return a;
	
		}
		catch(Exception e){
			e.printStackTrace();
			
		}
		return -1;
		
	}
	public static int DeleteAbsentform() throws SQLException
	{
		try{
			Connection con=DbUtil.getConnection();
			String str2=q18;
			PreparedStatement ps2=con.prepareStatement(str2);
			int b =ps2.executeUpdate();
			
			con.close();
			return (b);
		
		}
		catch(Exception e){
			e.printStackTrace();
			
		}
		return -1;
		
	}
	public static int changeLogin() throws SQLException
	{
		
		try{
			
			Connection con=DbUtil.getConnection();
			String str=q19;
			PreparedStatement ps=con.prepareStatement(str);
			
			int a=ps.executeUpdate();
		
			con.close();
			return (a);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return -1;
		
	}

}
