package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.AbsentForm;
import com.bean.FeedbackClass;
import com.bean.LoginClass;
import com.bean.Registration;
import com.dao.DBdao;
import com.service.DBservice;
//import com.sun.corba.se.spi.protocol.RequestDispatcherDefault;
import com.util.DbUtil;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	
			protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

			
					response.setContentType("text/html");
					PrintWriter pw=response.getWriter();
					Connection con = null;
					 String action = request.getParameter("action");
				
					 String target="";
						HttpSession hsn=request.getSession();
						DBservice ds= new DBservice();
				
					
	try{
			
	 if(action.equals("Present")){
							
							 ArrayList <LoginClass> al= ds.PAList();
							
							 ArrayList<LoginClass> p= new ArrayList<LoginClass>();
							
							   for(LoginClass a: al){
							   if(a.getAttendance().equalsIgnoreCase("Present"))
							   { 
								   
								   p.add(a);
								
								  
							   }
							  
							   }
							 
							   hsn.setAttribute("PAList", p);
								  RequestDispatcher rd = request.getRequestDispatcher("JSP/Present.jsp");
								 rd.forward(request, response);
			
					}
	 else if(action.equals("Absent")){
							 ArrayList <LoginClass> al= ds.PAList();	
							 ArrayList<LoginClass> ab= new ArrayList<LoginClass>();
							
							   for(LoginClass a: al){
								   
							   if(a.getAttendance().equalsIgnoreCase("Absent")){ 
								   ab.add(a);
							   }
							  
							   }
						 hsn.setAttribute("PAList", ab);
						  RequestDispatcher rd = request.getRequestDispatcher("JSP/Present.jsp");
						  rd.forward(request, response);
						 }
	  else if(action.equals("Classroom Session"))
						   {
							  int id = (Integer)hsn.getAttribute("empid");
							
							 	if( ds.attandance(id)){
							 			
							 			 response.sendRedirect("JSP/PresentConf.jsp");
							 	}
							 	else{
							 		response.sendRedirect("JSP/Error.jsp");
							 	
							 		
							 	}
						   	}
	    else if(action.equals("Login")){
							 int empid=Integer.parseInt(request.getParameter("uname"));
								String pwd=request.getParameter("psw");
					      	String fname=ds.getName(empid);
					      	hsn.setAttribute("fname", fname);
						          LoginClass lc=new LoginClass (empid, pwd);
						           hsn.setAttribute("empid", empid);
						           hsn.setAttribute("pwd", pwd);
						        		   if(ds.setValidateLogin(lc)==1){
						        			  
						        			  response.sendRedirect("JSP/Dashboard.jsp");
						        			 
						        			 	        			
						        		   }
                                     else if(ds.setValidateLogin(lc)==2){
						        			  
						        			
						        			   response.sendRedirect("JSP/GenerateReport.jsp");
						        			 	        			
						        		   }
						        		   else
						        		   {  
						        			   hsn.setAttribute("loginResult", "true");
						        			   response.sendRedirect("JSP/Login.jsp");
						        			  
						        		   }
					         }
				 
	  else if(action.equals("WebEx Session")){
					      	   int  eid=(int)(hsn.getAttribute("empid"));
						    	
					      	 String pwd=(String)(hsn.getAttribute("psw"));
					      
					      

						       LoginClass lc=new LoginClass (eid,"pwd");
						   //        hsn.setAttribute("empid", eid);
						         
						         if(ds.setWebEx(lc)){
						        			  
						       	  response.sendRedirect("JSP/Feedback.jsp");
						      	  // RequestDispatcher rd = request.getRequestDispatcher("Dashboard.jsp");
						        		//  rd.forward(request, response);
						        			 	        			
						       	   }
						        		  
						        		  
						           else {
						       	   response.sendRedirect("JSP/AbsentAlert.jsp");
						        		   }
					      
						 }
		else if(action.equals("Send Feedback")){

								 //String attendance =(String) hsn.getAttribute("attendance");
						    	 
						       if( ds.sendfeedback()){
						    	   RequestDispatcher rd = request.getRequestDispatcher("JSP/alert.jsp");
									  rd.forward(request, response);
						    	
							}
						       else{
						    	   RequestDispatcher rd = request.getRequestDispatcher("JSP/alert.jsp");
									  rd.forward(request, response);
						    	  
						       }
						       
						      }
		else if(action.equals("Send Notification for Absentees")){
				 
			        if( ds.sendNotification()){
			  	 
						    	   RequestDispatcher rd = request.getRequestDispatcher("JSP/Alert1.jsp");
									  rd.forward(request, response);
						    	
							}
			       else{

			    	   RequestDispatcher rd = request.getRequestDispatcher("JSP/Alert1.jsp");
						  rd.forward(request, response);
			  }
						 
					}	
						 
		else if(action.equals("Logout")|| action.equals("LOGOUT")){
					        HttpSession session=request.getSession(false);  
					        session.invalidate(); 
				     
					        response.sendRedirect("JSP/LogoutConf.jsp");
			}
						 
		else if(action.equals("Register"))
							{
				
								String fname=request.getParameter("firstname");
								
								String lname=request.getParameter("lastname");
								String gender=request.getParameter("gender");
								String email=request.getParameter("email");
								String pwd=request.getParameter("password");
								String state=request.getParameter("state");
								String area=request.getParameter("area");
								String bgp=request.getParameter("bloodgroup");
								
								int age=Integer.parseInt(request.getParameter("age"));
								double cno=Double.parseDouble(request.getParameter("phoneNumber"));
								int weight=Integer.parseInt(request.getParameter("weight"));
								int pin=Integer.parseInt(request.getParameter("pincode"));
								//int empid=Integer.parseInt(request.getParameter("empid"));
								int empid = ds.autoIncrement();
							Registration r= new Registration(fname, lname, age, gender, email, pwd, state, area, bgp, cno, weight, pin, empid);
						         LoginClass lc= new  LoginClass (empid,pwd);
							   // hsn.setAttribute("username", uname);
							    //hsn.setAttribute("amount", amt);
						         int x=ds.setUserData(r);
						        int y= ds.setLoginUserData(lc);

								if(y>0)
								{
									System.out.println("Inserted");
									//target="Login.html";
								}
								else
								{   response.sendRedirect("JSP/Error.jsp");
									System.out.println(" Not Inserted");
									//pw.write("Insertion unsuccessful");
								}
								
								
								
								if(y>0)
								{
									
									response.sendRedirect("JSP/RegistrationSuccessful.jsp");
			 	        			
								}
								else
								{
									response.sendRedirect("JSP/Error.jsp");
									
								}
								
							}
								
		else if(action.equals("feedback"))
			{
				
			    	 int id = (Integer)hsn.getAttribute("empid");
				     String training=request.getParameter("training");
				     String satisfaction=request.getParameter("satisfaction");
				     String attended_before=request.getParameter("attended_before");
				     String recommend=request.getParameter("recommend");
				
				
				     FeedbackClass fc= new FeedbackClass(id, training, satisfaction, attended_before, recommend);

				     int x=ds.setFeedbackData(fc);
				     if(x>0)
				     {
				    	  hsn.setAttribute("CP", "true");
	        			   response.sendRedirect("JSP/FeedbackAlert.jsp");
				    	
				     }
				
				     else
				     {
				    	 response.sendRedirect("JSP/Error.jsp");
				    	
				     }
		
			 }	 
		else if(action.equals("Save"))
				{	 
					
					int empid = (Integer)hsn.getAttribute("empid");
					String pwd=request.getParameter("OldPassword");
					String newPassword=request.getParameter("newpassword");
					String confirmPassword=request.getParameter("conpassword");
					LoginClass lc= new LoginClass(empid, pwd, newPassword);
				
					if(pwd.equals(lc.getPwd()) && newPassword.equals(confirmPassword) ){
						if( ds.changePassword(lc)){
						
				    	   RequestDispatcher rd = request.getRequestDispatcher("JSP/Pswchange.jsp");
							  rd.forward(request, response);
				    	
					}
				       else{
				    	   

	        			   hsn.setAttribute("CP", "true");
	        			   response.sendRedirect("JSP/ChangePassword.jsp");
	        			  
				    	  
				       }
					}
					else
	        		   {  
	        			   hsn.setAttribute("CP", "true");
	        			   response.sendRedirect("JSP/ChangePassword.jsp");
        			  
        		   }
		
			}	
	/*	else if(action.equals("Notification")){
				int id = (Integer)hsn.getAttribute("empid");
				if(ds.notification(id)){
					 RequestDispatcher rd = request.getRequestDispatcher("JSP/Reason.jsp");
					  rd.forward(request, response);
				}
				else
				{
					RequestDispatcher rd = request.getRequestDispatcher("JSP/AbsentForm.jsp");
					  rd.forward(request, response);
				}
				
				}*/
						 
		else if(action.equals("submit")){
						
						 int id = (Integer)hsn.getAttribute("empid");
						String course=request.getParameter("course");
						String reason=request.getParameter("reason");
						
						AbsentForm af= new AbsentForm(id, course, reason);
						int x=ds.setAbsentReason(af);
						if(x>0)
						{
							
							response.sendRedirect("JSP/AbsentFormSubmitAlert.jsp");
							//target="Login.html";
						}
						else
						{
							
							response.sendRedirect("JSP/Error.jsp");
							//pw.write("Insertion unsuccessful");
						}
						
					}

		else if(action.equals("View Absenteeism")){
							
							 ArrayList <AbsentForm> arr= ds.PAList1();
							
							
							
							   hsn.setAttribute("PAList1", arr);
						   response.sendRedirect("JSP/DisplayAbsentTable.jsp");
					}	
		else if(action.equals("View Feedback Entries")){
							
							 ArrayList <FeedbackClass> arr= ds.PAList2();
							
							
							   hsn.setAttribute("PAList2", arr);
//						
//						  RequestDispatcher rd = request.getRequestDispatcher("JSP/DisplayAbsentTable.jsp");
//						 rd.forward(request, response);
							   response.sendRedirect("JSP/DisplayFeedbackTable.jsp");
					}	
	else if(action.equals("Clear Session Data")){
			    if(ds.DeleteAbsentform()>=0  && ds.DeleteFeedback()>=0 && ds.changeLogin()>=0 ){
				
				  response.sendRedirect("JSP/DeleteAlert.jsp");
			    }
			    else
			  {
				  response.sendRedirect("JSP/Error.jsp");
				  
			  }
			
			  // response.sendRedirect("JSP/DisplayFeedbackTable.jsp");
	            }	
	 
	else if(action.equals("LOGIN")){
		
		       response.sendRedirect("JSP/Login.jsp");
              }	

	 
	else if(action.equals("SIGN UP")){
			     response.sendRedirect("JSP/Signup.jsp");
			 
	          }	
	 
	else if(action.equals("ABOUT TEAM")){
			  response.sendRedirect("JSP/OurTeam.jsp");
			 
	          }	

	else if(action.equals("HOME")){
			  response.sendRedirect("JSP/GenerateReport.jsp");
			 
	          }	

	else if(action.equals("Generate Report")){
	         	  response.sendRedirect("JSP/PASwitch.jsp");
			 
	          }	
	else if(action.equals("View Notification")){
   	  response.sendRedirect("JSP/AdminNotify.jsp");
	 
    }	

	 
	else if(action.equals("About Team")){
		  response.sendRedirect("JSP/OurTeam1.jsp");
				 
		          }	

	else if(action.equals("Home")){
		  response.sendRedirect("JSP/Dashboard.jsp");
				 
		          }	

	 else if(action.equals("Change Password")){
    	  response.sendRedirect("JSP/ChangePassword.jsp");
	 
     }	
	 
	 
	 
	 else if(action.equals("Notification")){
		
    	   int  eid=(int)(hsn.getAttribute("empid"));
	    	
    	 String pwd=(String)(hsn.getAttribute("psw"));
    	
    

	       LoginClass lc=new LoginClass (eid,"pwd");
	   //        hsn.setAttribute("empid", eid);
	       
	      // int id = (Integer)hsn.getAttribute("empid");
			
	      if(ds.notification(eid)){
	                 if(ds.setWebEx(lc)){
	        	    
	        		
					 RequestDispatcher rd = request.getRequestDispatcher("JSP/Reason.jsp");
					  rd.forward(request, response);
	                 }
                  else {
	        	   
	       	            response.sendRedirect("JSP/AbsentAlert.jsp");
	        		   }
	      }  
	      
	      else
	      {
	    	    if(ds.setWebEx1(lc)){
	        	    
	        		
					 RequestDispatcher rd = request.getRequestDispatcher("JSP/AbsentForm.jsp");
					  rd.forward(request, response);
	    	    }
          else {
	        	  
	       	   response.sendRedirect("JSP/AbsentAlert.jsp");
	        		   }
	      }
	 }      
	
		    else{
			 response.sendRedirect("JSP/Error.jsp");
		        }
			
					}
					catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
	
		
					
			pw.close();

		         
		         }
			
			 
			 
			 
			
		
		   
		   
			 
			 
			 
			 
		
			/**
			 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
