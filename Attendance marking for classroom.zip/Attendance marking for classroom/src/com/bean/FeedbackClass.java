package com.bean;

public class FeedbackClass {
	int empid;
	String training, satisfaction, attended_before, recommend;

	

	public FeedbackClass(int empid, String training, String satisfaction, String attended_before, String recommend) {
		super();
		this.empid = empid;
		this.training = training;
		this.satisfaction = satisfaction;
		this.attended_before = attended_before;
		this.recommend = recommend;
	}



	public FeedbackClass() {
		super();
	}

	

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getTraining() {
		return training;
	}

	public void setTraining(String training) {
		this.training = training;
	}

	public String getSatisfaction() {
		return satisfaction;
	}

	public void setSatisfaction(String satisfaction) {
		this.satisfaction = satisfaction;
	}

	public String getAttended_before() {
		return attended_before;
	}

	public void setAttended_before(String attended_before) {
		this.attended_before = attended_before;
	}

	public String getRecommend() {
		return recommend;
	}

	@Override
	public String toString() {
		return "FeedbackClass [empid=" + empid + ", training=" + training + ", satisfaction=" + satisfaction
				+ ", attended_before=" + attended_before + ", recommend=" + recommend + "]";
	}



	public void setRecommend(String recommend) {
		this.recommend = recommend;
	}
	

}
