package com.bean;

public class AbsentForm {
	
	int empid;
	String course, reason;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public AbsentForm(int empid, String course, String reason) {
		super();
		this.empid = empid;
		this.course = course;
		this.reason = reason;
	}
	public AbsentForm() {
		super();
	}
	@Override
	public String toString() {
		return "AbsentForm [empid=" + empid + ", course=" + course + ", reason=" + reason + "]";
	}
	
	

}
