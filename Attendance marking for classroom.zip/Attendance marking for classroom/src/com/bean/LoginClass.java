package com.bean;

public class LoginClass {

	int empid;
	String pwd, attendance, type,feedbackstatus, newPassword;
	
	public LoginClass(int empid, String pwd, String attendance, String type, String feedbackstatus, String newPassword) {
		super();
		this.empid = empid;
		this.pwd = pwd;
		this.attendance = attendance;
		this.type = type;
		this.feedbackstatus = feedbackstatus;
		this.newPassword = newPassword;
	}
	public LoginClass (){
		
	}
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getAttendance() {
		return attendance;
	}
	public void setAttendance(String attendance) {
		this.attendance = attendance;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getFeedbackstatus() {
		return feedbackstatus;
	}
	public void setFeedbackstatus(String feedbackstatus) {
		this.feedbackstatus = feedbackstatus;
	}
	
	public LoginClass(int empid, String pwd, String newPassword) {
		super();
		this.empid = empid;
		this.pwd = pwd;
		this.newPassword = newPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	
	
	public LoginClass(int empid, String pwd) {
		super();
		this.empid = empid;
		this.pwd = pwd;
	}
	public LoginClass(int empid, String pwd, String attendance, String type) {
		super();
		this.empid = empid;
		this.pwd = pwd;
		this.attendance = attendance;
		this.type = type;
	}
	@Override
	public String toString() {
		return "LoginClass [empid=" + empid + ", pwd=" + pwd + ", attendance=" + attendance + ", type=" + type + "]";
	}
	
	
}
