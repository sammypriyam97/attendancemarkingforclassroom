package com.bean;

public class Registration {

	String fname,lname,gender,email,pwd,state ,area,bgp;
	int age,weight ,pin  ,empid ;
	double cno;
	public Registration()
	{
		
	}
	
	public Registration(String fname, String lname, int age, String gender, String email, String pwd, String state, String area,
			String bgp, double cno, int weight, int pin, int empid) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.gender = gender;
		this.email = email;
		this.pwd = pwd;
		this.state = state;
		this.area = area;
		this.bgp = bgp;
		this.age = age;
		this.cno = cno;
		this.weight = weight;
		this.pin = pin;
		this.empid = empid;
	}
	
	
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getBgp() {
		return bgp;
	}
	public void setBgp(String bgp) {
		this.bgp = bgp;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getCno() {
		return cno;
	}
	public void setCno(int cno) {
		this.cno = cno;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	
	
}
